package com.dhlecom.springbooth2.controller;

import com.dhlecom.springbooth2.dao.ShipmentRepository;
import com.dhlecom.springbooth2.model.Shipment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ShipmentController {

    @Autowired
    ShipmentRepository shipmentRepository;

    @PostMapping("/saveShipment")
    public String saveShipment(@RequestBody Shipment shipment){
        shipmentRepository.save(shipment);
        return "Shipment with tracking number -> "+shipment.getTrackingNumber()+" saved";
    }

    @GetMapping("/getAllShipments")
    public List<Shipment> getAllShipment(){
        return shipmentRepository.findAll();
    }
}
