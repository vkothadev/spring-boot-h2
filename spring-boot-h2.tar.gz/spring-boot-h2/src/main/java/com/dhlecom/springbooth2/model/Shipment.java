package com.dhlecom.springbooth2.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.tomcat.jni.Address;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Shipment {
    @Id
    @GeneratedValue
    private int trackingNumber;
    private String consigneeName;
    private int contactNumber;
    private String address;
    private double charge;
    private String size;
    private double weight;
}
