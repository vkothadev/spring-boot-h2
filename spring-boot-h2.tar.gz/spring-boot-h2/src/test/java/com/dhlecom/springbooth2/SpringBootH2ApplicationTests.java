package com.dhlecom.springbooth2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootH2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
